// Gryffin.cs

using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using Robocode.TankRoyale.BotApi;
using Robocode.TankRoyale.BotApi.Events;

public class Gryffin : Bot
{
        private const double SafeMargin = 56.0;
    private const double WallSoftMargin = 124.0;
    private const double WallHardMargin = 68.0;
    private const double CriticalEnergy = 12.0;
    private const double LowEnergy = 20.0;
    private const double RecoverEnergy = 34.0;
    private const double RecentLocCount = 42;
    private const double RecentCellCount = 30;
    private const double BaseTravel = 138.0;
    private const double DuelTravel = 160.0;
    private const double MeleeTravel = 150.0;

    private readonly Random _rng = new();
    private readonly Dictionary<int, EnemyInfo> _enemies = new();
    private readonly LinkedList<OldLocation> _recentLocs = new();
    private readonly HashSet<int> _visitedCells = new();
    private readonly Queue<int> _visitedCellOrder = new();

    private int _moveHoldTurns;
    private double _lastMoveHeading;
    private int _lastTargetId = -1;
    private int _lastOrbitFlipTurn = -999;
    private int _lastModeShiftTurn = -999;
    private int _panicUntil;
    private int _pressUntil;
    private int _forceCenterUntil;
    private int _radarSweepDir = 1;
    private int _orbitSign = 1;

    private enum TacticalMode
    {
        Stabilize,
        Hunt,
        BreakLine,
        Pressure,
        Recover
    }

    private TacticalMode _mode = TacticalMode.Stabilize;

    private sealed class EnemyInfo
    {
        public int Id { get; init; }
        public double X { get; set; }
        public double Y { get; set; }
        public double PrevX { get; set; }
        public double PrevY { get; set; }
        public double Energy { get; set; }
        public double Direction { get; set; }
        public double PrevDirection { get; set; }
        public double Speed { get; set; }
        public double PrevSpeed { get; set; }
        public double VelocityX { get; set; }
        public double VelocityY { get; set; }
        public double DirectionVar { get; set; }
        public double SpeedVar { get; set; }
        public double ThreatIndex { get; set; }
        public double PressureIndex { get; set; }
        public double FinishIndex { get; set; }
        public int LastSeenTurn { get; set; }
        public int ScanCount { get; set; }
        public bool Alive { get; set; } = true;
        public double DamageTaken { get; set; }
        public double DamageFactor { get; set; } = 1.0;
        public double TotalDistance { get; set; }
        public int TurnsTracked { get; set; }
        public bool HasSample { get; set; }
    }

    private readonly record struct OldLocation(double X, double Y);
    private readonly record struct LaneCandidate(double Heading, double SpeedFactor, double X, double Y, double ScoreBias);
    private readonly record struct AimPoint(double X, double Y);

    static void Main(string[] args) => new Gryffin().Start();
    Gryffin() : base(BotInfo.FromFile("Gryffin.json")) { }

    public override void Run()
    {
        BodyColor = Color.DimGray;
        GunColor = Color.Black;
        RadarColor = Color.Cyan;
        BulletColor = Color.Orange;
        ScanColor = Color.LimeGreen;
        TracksColor = Color.Silver;
        TurretColor = Color.DarkGray;

        AdjustGunForBodyTurn = true;
        AdjustRadarForBodyTurn = true;
        AdjustRadarForGunTurn = true;
        MaxSpeed = 8;

        while (IsRunning)
        {
            PurgeDeadEnemies();
            SetTurnRadarRight(360.0);

            RefreshTacticalMode();
            ExecuteMovement();

            var target = SelectTarget();
            AimGun(target);

            Go();
        }
    }

    private void RefreshTacticalMode()
    {
        int alive = AliveEnemies().Count;
        bool lowEnergy = Energy < LowEnergy;
        bool critical = Energy <= CriticalEnergy;
        bool underPressure = TurnNumber < _panicUntil;
        bool forcedCenter = TurnNumber < _forceCenterUntil;

        TacticalMode next;
        if (critical)
            next = TacticalMode.Recover;
        else if (forcedCenter || IsNearBoundary(SafeMargin))
            next = TacticalMode.Stabilize;
        else if (underPressure)
            next = TacticalMode.BreakLine;
        else if (alive >= 3)
            next = TacticalMode.Pressure;
        else if (lowEnergy)
            next = TacticalMode.Hunt;
        else
            next = TacticalMode.Hunt;

        if (next != _mode)
            _lastModeShiftTurn = TurnNumber;

        _mode = next;
    }

    private void ExecuteMovement()
    {
        double cx = ArenaWidth / 2.0;
        double cy = ArenaHeight / 2.0;

        if (_moveHoldTurns > 0)
        {
            _moveHoldTurns--;
            DriveInDirection(_lastMoveHeading, 8.0);
            return;
        }

        if (IsNearBoundary(SafeMargin) || IsEnergyCritical())
        {
            double home = DirectionTo(cx, cy);
            _lastMoveHeading = home;
            _moveHoldTurns = 1;
            DriveInDirection(home, IsEnergyCritical() ? 8.0 : 7.0);
            return;
        }

        UpdateRecentLocations();
        var enemies = AliveEnemies();
        if (enemies.Count == 0)
        {
            double roam = NormalizeAbsoluteAngle(Direction + 37.0 * _orbitSign);
            _lastMoveHeading = roam;
            _moveHoldTurns = 1;
            DriveInDirection(roam, 4.5);
            return;
        }

        var primary = SelectPrimaryThreat(enemies);
        var candidates = BuildMovementCandidates(enemies, primary, cx, cy);

        double bestScore = double.NegativeInfinity;
        LaneCandidate best = candidates[0];

        foreach (var candidate in candidates)
        {
            double score = ScoreLane(candidate, enemies, primary, cx, cy);
            if (score > bestScore)
            {
                bestScore = score;
                best = candidate;
            }
        }

        _lastMoveHeading = best.Heading;
        _moveHoldTurns = bestScore > 28.0 ? 3 : bestScore > 18.0 ? 2 : 1;
        DriveInDirection(best.Heading, 8.0 * best.SpeedFactor);
    }

    private List<LaneCandidate> BuildMovementCandidates(List<EnemyInfo> enemies, EnemyInfo primary, double cx, double cy)
    {
        double toThreat = DirectionTo(primary.X, primary.Y);
        double awayThreat = NormalizeAbsoluteAngle(toThreat + 180.0);
        double escapeCentroid = EscapeHeadingFromCentroid(enemies);
        double centerHeading = DirectionTo(cx, cy);
        double angularPush = 92.0 * _orbitSign;
        double shallowPush = 54.0 * _orbitSign;
        double cutPush = 128.0 * _orbitSign;

        var list = new List<LaneCandidate>
        {
            BuildLane(awayThreat, BaseTravel, 1.00),
            BuildLane(NormalizeAbsoluteAngle(toThreat + angularPush), DuelTravel, 1.00),
            BuildLane(NormalizeAbsoluteAngle(toThreat - angularPush), DuelTravel, 1.00),
            BuildLane(NormalizeAbsoluteAngle(toThreat + shallowPush), BaseTravel * 0.92, 0.97),
            BuildLane(NormalizeAbsoluteAngle(toThreat - shallowPush), BaseTravel * 0.92, 0.97),
            BuildLane(escapeCentroid, MeleeTravel, 0.94),
            BuildLane(centerHeading, BaseTravel * 0.88, 0.88),
            BuildLane(NormalizeAbsoluteAngle(Direction + 28.0), BaseTravel * 0.74, 0.82),
            BuildLane(NormalizeAbsoluteAngle(Direction - 28.0), BaseTravel * 0.74, 0.82),
            BuildLane(NormalizeAbsoluteAngle(toThreat + cutPush), BaseTravel * 0.98, 0.90),
            BuildLane(NormalizeAbsoluteAngle(toThreat - cutPush), BaseTravel * 0.98, 0.90),
            BuildLane(NormalizeAbsoluteAngle(awayThreat + 35.0 * _orbitSign), BaseTravel * 0.82, 0.87)
        };

        if (_mode == TacticalMode.Pressure)
            list.Add(BuildLane(NormalizeAbsoluteAngle(toThreat + 180.0 + 25.0 * _orbitSign), BaseTravel * 0.95, 0.95));

        if (_mode == TacticalMode.Recover)
            list.Add(BuildLane(centerHeading, BaseTravel * 0.95, 0.80));

        return list;
    }

    private LaneCandidate BuildLane(double heading, double distance, double speedFactor)
    {
        double normalized = NormalizeAbsoluteAngle(heading);
        var projected = ProjectStep(normalized, distance);
        return new LaneCandidate(normalized, speedFactor, projected.X, projected.Y, 0.0);
    }

    private (double X, double Y) ProjectStep(double heading, double distance)
    {
        double rad = ToRadians(heading);
        double x = X + Math.Cos(rad) * distance;
        double y = Y + Math.Sin(rad) * distance;
        x = Math.Clamp(x, Constants.BoundingCircleRadius, ArenaWidth - Constants.BoundingCircleRadius);
        y = Math.Clamp(y, Constants.BoundingCircleRadius, ArenaHeight - Constants.BoundingCircleRadius);
        return (x, y);
    }

    private double ScoreLane(LaneCandidate candidate, List<EnemyInfo> enemies, EnemyInfo primary, double cx, double cy)
    {
        if (candidate.X < Constants.BoundingCircleRadius || candidate.Y < Constants.BoundingCircleRadius ||
            candidate.X > ArenaWidth - Constants.BoundingCircleRadius || candidate.Y > ArenaHeight - Constants.BoundingCircleRadius)
            return -1_000_000.0;

        double minEnemy = double.PositiveInfinity;
        double weightedEnemyField = 0.0;
        double centroidX = 0.0, centroidY = 0.0, wSum = 0.0;

        foreach (var e in enemies)
        {
            double d = Distance(candidate.X, candidate.Y, e.X, e.Y);
            minEnemy = Math.Min(minEnemy, d);
            weightedEnemyField += (1.0 + e.Energy / 100.0) / Math.Max(d * d, 1.0);

            double w = (0.5 + e.ThreatIndex) / Math.Max(d, 55.0);
            centroidX += e.X * w;
            centroidY += e.Y * w;
            wSum += w;
        }

        centroidX = wSum > 0 ? centroidX / wSum : primary.X;
        centroidY = wSum > 0 ? centroidY / wSum : primary.Y;

        double wallSafety = WallSafety(candidate.X, candidate.Y);
        double wallScore = Math.Clamp(wallSafety / WallSoftMargin, 0.0, 1.25) * 2.9;

        double targetDistance = Distance(candidate.X, candidate.Y, primary.X, primary.Y);
        double ideal = _mode == TacticalMode.Pressure ? 245.0 : Energy > 40 ? 280.0 : Energy > 20 ? 345.0 : 420.0;
        double ringScore = 1.0 - Math.Min(Math.Abs(targetDistance - ideal), 540.0) / 540.0;

        double centroidEscape = Distance(candidate.X, candidate.Y, centroidX, centroidY);
        double centroidScore = Math.Clamp(centroidEscape / 420.0, 0.0, 1.0);

        double lateral = Math.Abs(Math.Sin(ToRadians(NormalizeRelativeAngle(candidate.Heading - DirectionTo(primary.X, primary.Y)))));
        double lateralScore = Math.Clamp(lateral, 0.0, 1.0);

        double turnPenalty = Math.Abs(NormalizeRelativeAngle(candidate.Heading - Direction)) / 180.0;
        double novelty = 1.0 - Math.Min(turnPenalty, 1.0);

        double revisitPenalty = 0.0;
        foreach (var old in _recentLocs)
        {
            double d = Distance(candidate.X, candidate.Y, old.X, old.Y);
            revisitPenalty += 1.0 / Math.Max(d, 12.0);
        }

        double cellPenalty = VisitedCellPenalty(candidate.X, candidate.Y);
        double closeDanger = minEnemy < 120.0 ? -140.0 * (1.0 - minEnemy / 120.0) : 0.0;
        double pressure = weightedEnemyField * 760.0;
        double centerDist = Distance(candidate.X, candidate.Y, cx, cy);
        double centerPull = _mode == TacticalMode.Stabilize ? 1.0 - Math.Min(centerDist / 520.0, 1.0) : 0.55 - Math.Min(Math.Abs(centerDist - 290.0), 500.0) / 1000.0;
        double bias = _mode == TacticalMode.Recover ? 0.8 : _mode == TacticalMode.Pressure ? 0.25 : 0.45;

        if (centerDist < 120.0)
            centerPull -= 0.25;
        if (centerDist > 330.0)
            centerPull += 0.15;

        double score =
            wallScore * 3.2 +
            ringScore * 2.2 +
            centroidScore * 1.6 +
            lateralScore * 1.5 +
            centerPull * 0.8 +
            novelty * 0.7 +
            bias -
            revisitPenalty * 1.4 -
            cellPenalty * 1.25 -
            pressure * 0.7 +
            closeDanger;

        if (candidate.SpeedFactor < 0.9 && Energy < RecoverEnergy)
            score += 4.0;

        if (IsEnemyAlignedWithPath(candidate.X, candidate.Y, primary))
            score -= 16.0;

        if (targetDistance < 160.0 && !ShouldRam(primary))
            score -= 24.0;

        if (candidate.SpeedFactor > 0.95 && _mode == TacticalMode.Pressure)
            score += 3.0;

        if (_mode == TacticalMode.BreakLine)
            score += Math.Abs(Math.Sin(ToRadians(candidate.Heading - Direction))) * 2.0;

        return score;
    }

    private double VisitedCellPenalty(double x, double y)
    {
        int gx = (int)(x / 44.0);
        int gy = (int)(y / 44.0);
        int key = (gx << 16) ^ gy;
        return _visitedCells.Contains(key) ? 2.1 : 0.0;
    }

    private bool IsEnemyAlignedWithPath(double x, double y, EnemyInfo threat)
    {
        double pathBearing = DirectionTo(x, y);
        double threatBearing = DirectionTo(threat.X, threat.Y);
        double delta = Math.Abs(NormalizeRelativeAngle(pathBearing - threatBearing));
        return delta < 28.0 || delta > 332.0;
    }

    private void DriveInDirection(double heading, double speed)
    {
        double turn = NormalizeRelativeAngle(heading - Direction);
        if (Math.Abs(turn) > 90.0)
        {
            double backTurn = NormalizeRelativeAngle(turn + 180.0);
            SetTurnLeft(backTurn);
            TargetSpeed = -Math.Abs(speed);
        }
        else
        {
            SetTurnLeft(turn);
            TargetSpeed = Math.Abs(speed);
        }
    }

    private void UpdateRecentLocations()
    {
        if (TurnNumber % 2 != 0)
            return;

        _recentLocs.AddFirst(new OldLocation(X, Y));
        while (_recentLocs.Count > RecentLocCount)
            _recentLocs.RemoveLast();

        int gx = (int)(X / 44.0);
        int gy = (int)(Y / 44.0);
        int key = (gx << 16) ^ gy;
        if (_visitedCells.Add(key))
            _visitedCellOrder.Enqueue(key);

        while (_visitedCellOrder.Count > RecentCellCount)
        {
            int old = _visitedCellOrder.Dequeue();
            _visitedCells.Remove(old);
        }
    }

    private double WallSafety(double x, double y)
    {
        double left = x - Constants.BoundingCircleRadius;
        double right = ArenaWidth - Constants.BoundingCircleRadius - x;
        double bottom = y - Constants.BoundingCircleRadius;
        double top = ArenaHeight - Constants.BoundingCircleRadius - y;
        return Math.Max(0.0, Math.Min(Math.Min(left, right), Math.Min(bottom, top)));
    }

    private bool IsNearBoundary(double margin) =>
        X < margin || Y < margin || X > ArenaWidth - margin || Y > ArenaHeight - margin;

    private static double Distance(double x1, double y1, double x2, double y2)
    {
        double dx = x2 - x1;
        double dy = y2 - y1;
        return Math.Sqrt(dx * dx + dy * dy);
    }

    private static double ToRadians(double angle) => angle * Math.PI / 180.0;

    private double EscapeHeadingFromCentroid(List<EnemyInfo> enemies)
    {
        double sumX = 0.0, sumY = 0.0, wSum = 0.0;
        foreach (var e in enemies)
        {
            double d = Math.Max(60.0, DistanceTo(e.X, e.Y));
            double w = (0.8 + Math.Min(e.Energy, 100.0) / 100.0) / d;
            sumX += e.X * w;
            sumY += e.Y * w;
            wSum += w;
        }

        if (wSum <= 0.0)
            return DirectionTo(ArenaWidth / 2.0, ArenaHeight / 2.0);

        return NormalizeAbsoluteAngle(DirectionTo(sumX / wSum, sumY / wSum) + 180.0);
    }

    private void AimGun(EnemyInfo? target)
    {
        if (target == null || GunHeat > 0.1)
        {
            SetFire(0);
            return;
        }

        double distance = DistanceTo(target.X, target.Y);
        double firepower = ChooseFirePower(target, distance);
        if (firepower <= 0.0)
        {
            SetFire(0);
            return;
        }

        var aim = PredictPosition(target, firepower);
        double gunTurn = NormalizeRelativeAngle(DirectionTo(aim.X, aim.Y) - GunDirection);
        SetTurnGunLeft(gunTurn);

        if (Math.Abs(gunTurn) < 8.0 && GunHeat == 0)
            SetFire(firepower);
        else
            SetFire(0);
    }

    private AimPoint PredictPosition(EnemyInfo e, double firepower)
    {
        double bulletSpeed = CalcBulletSpeed(firepower);
        double ticks = Math.Clamp(DistanceTo(e.X, e.Y) / bulletSpeed, 1.0, 15.0);

        double headingRad = ToRadians(e.Direction);
        double measuredVx = Math.Cos(headingRad) * e.Speed;
        double measuredVy = Math.Sin(headingRad) * e.Speed;
        double stability = Math.Clamp(1.0 - Math.Abs(e.DirectionVar) / 20.0, 0.22, 1.0);
        double blend = 0.24 + 0.48 * stability;
        double turnBias = Math.Clamp(e.DirectionVar, -13.0, 13.0);

        double px = e.X;
        double py = e.Y;

        for (int i = 0; i < 4; i++)
        {
            double predictedHeading = ToRadians(e.Direction + turnBias * ticks * blend);
            double ax = Math.Cos(predictedHeading) * e.Speed * ticks;
            double ay = Math.Sin(predictedHeading) * e.Speed * ticks;

            double vx = e.VelocityX * (1.0 - blend) + measuredVx * blend;
            double vy = e.VelocityY * (1.0 - blend) + measuredVy * blend;

            px = e.X + (vx * (1.0 - blend) + ax * blend) * ticks * 0.9;
            py = e.Y + (vy * (1.0 - blend) + ay * blend) * ticks * 0.9;

            if (px < Constants.BoundingCircleRadius || px > ArenaWidth - Constants.BoundingCircleRadius ||
                py < Constants.BoundingCircleRadius || py > ArenaHeight - Constants.BoundingCircleRadius)
            {
                px = Math.Clamp(px, Constants.BoundingCircleRadius, ArenaWidth - Constants.BoundingCircleRadius);
                py = Math.Clamp(py, Constants.BoundingCircleRadius, ArenaHeight - Constants.BoundingCircleRadius);
                break;
            }

            ticks = DistanceTo(px, py) / bulletSpeed;
        }

        return new AimPoint(px, py);
    }

    private EnemyInfo? SelectTarget()
    {
        EnemyInfo? best = null;
        double bestScore = double.NegativeInfinity;

        foreach (var e in _enemies.Values)
        {
            if (!e.Alive)
                continue;

            int age = TurnNumber - e.LastSeenTurn;
            if (age > 30)
                continue;

            double score = ScoreTarget(e, age);
            if (score > bestScore)
            {
                bestScore = score;
                best = e;
            }
        }

        if (best != null)
            _lastTargetId = best.Id;

        return best;
    }

    private double ScoreTarget(EnemyInfo e, int age)
    {
        double distance = DistanceTo(e.X, e.Y);
        double distanceScore = 1.0 - Math.Min(distance / 760.0, 1.0);
        double energyScore = 1.0 - Math.Min(e.Energy / 100.0, 1.0);
        double damageScore = Math.Clamp(e.DamageFactor / 18.0, 0.0, 1.2);
        double instabilityScore = Math.Clamp(Math.Abs(e.DirectionVar) / 24.0, 0.0, 1.0);
        double predictabilityScore = 1.0 - Math.Clamp(Math.Abs(e.SpeedVar) / 8.0, 0.0, 1.0);
        double freshnessScore = 1.0 - Math.Min(age / 30.0, 1.0);
        double finishBonus = e.Energy <= 15.0 ? 0.7 : 0.0;
        double continuity = e.Id == _lastTargetId ? 0.14 : 0.0;

        return
            distanceScore * 2.15 +
            energyScore * 2.0 +
            damageScore * 1.7 +
            predictabilityScore * 1.9 +
            instabilityScore * 0.9 +
            freshnessScore * 0.85 +
            finishBonus +
            continuity;
    }

    private double ChooseFirePower(EnemyInfo target, double distance)
    {
        if (IsEnergyCritical())
            return 0.0;

        double power = distance switch
        {
            < 110 => 3.0,
            < 210 => 2.5,
            < 360 => 1.9,
            < 520 => 1.3,
            < 700 => 0.85,
            _ => 0.55,
        };

        if (target.Energy <= 12.0)
            power = Math.Max(power, 2.8);

        int alive = AliveEnemies().Count;
        if (alive >= 4)
            power = Math.Min(power, 1.6);
        else if (alive == 3)
            power = Math.Min(power, 2.05);
        else if (alive == 2)
            power = Math.Min(power, 2.35);

        if (Energy < LowEnergy)
            power = Math.Min(power, 1.05);
        if (Energy < CriticalEnergy)
            power = 0.0;

        return Math.Clamp(power, Constants.MinFirepower, Constants.MaxFirepower);
    }

    public override void OnScannedBot(ScannedBotEvent evt)
    {
        if (IsTeammate(evt.ScannedBotId))
            return;

        var e = GetOrCreate(evt.ScannedBotId);
        double dist = DistanceTo(evt.X, evt.Y);

        e.PrevX = e.X;
        e.PrevY = e.Y;
        e.PrevDirection = e.Direction;
        e.PrevSpeed = e.Speed;

        if (e.HasSample)
        {
            int deltaTurn = Math.Max(1, evt.TurnNumber - e.LastSeenTurn);
            double measuredVx = (evt.X - e.X) / deltaTurn;
            double measuredVy = (evt.Y - e.Y) / deltaTurn;
            double dirRad = ToRadians(evt.Direction);
            double directionalVx = Math.Cos(dirRad) * evt.Speed;
            double directionalVy = Math.Sin(dirRad) * evt.Speed;
            e.VelocityX = measuredVx * 0.62 + directionalVx * 0.38;
            e.VelocityY = measuredVy * 0.62 + directionalVy * 0.38;
        }
        else
        {
            double dirRad = ToRadians(evt.Direction);
            e.VelocityX = Math.Cos(dirRad) * evt.Speed;
            e.VelocityY = Math.Sin(dirRad) * evt.Speed;
            e.HasSample = true;
        }

        e.X = evt.X;
        e.Y = evt.Y;
        e.Energy = evt.Energy;
        e.Direction = evt.Direction;
        e.Speed = evt.Speed;
        e.LastSeenTurn = evt.TurnNumber;
        e.Alive = true;

        e.ScanCount++;
        e.TotalDistance += dist;
        e.TurnsTracked++;

        double dirDelta = NormalizeRelativeAngle(e.Direction - e.PrevDirection);
        double speedDelta = e.Speed - e.PrevSpeed;
        e.DirectionVar = e.DirectionVar * 0.70 + dirDelta * 0.30;
        e.SpeedVar = e.SpeedVar * 0.70 + speedDelta * 0.30;

        double baseThreat = (100.0 - Math.Min(100.0, e.Energy)) / 100.0;
        double rangeThreat = 1.0 - Math.Min(dist / 720.0, 1.0);
        double instability = Math.Clamp(Math.Abs(e.DirectionVar) / 22.0, 0.0, 1.0);
        e.ThreatIndex = baseThreat * 0.55 + rangeThreat * 0.35 + instability * 0.45;

        double damageBoost = (e.DamageTaken + 9.0) * (1.0 + Math.Min(e.TotalDistance / Math.Max(e.TurnsTracked, 1), 520.0) / 520.0);
        double stabilityPenalty = 1.0 + Math.Min(Math.Abs(e.DirectionVar) / 28.0, 0.55);
        e.DamageFactor = damageBoost / stabilityPenalty;
        e.PressureIndex = e.ThreatIndex + Math.Clamp(e.DamageFactor / 18.0, 0.0, 1.2);
        e.FinishIndex = e.Energy <= 15.0 ? 1.0 : 0.0;

        if (e.PressureIndex > 1.1 && dist < 680.0)
        {
            _panicUntil = Math.Max(_panicUntil, TurnNumber + 9);
            _forceCenterUntil = Math.Max(_forceCenterUntil, TurnNumber + 7);
        }
    }

    public override void OnBotDeath(BotDeathEvent evt)
    {
        if (_enemies.TryGetValue(evt.VictimId, out var e))
            e.Alive = false;
    }

    public override void OnHitWall(HitWallEvent evt)
    {
        _moveHoldTurns = 2;
        _forceCenterUntil = Math.Max(_forceCenterUntil, TurnNumber + 12);
        _orbitSign *= -1;
        _lastOrbitFlipTurn = TurnNumber;
        _lastMoveHeading = DirectionTo(ArenaWidth / 2.0, ArenaHeight / 2.0);
        TargetSpeed = -8.0;
        SetTurnLeft(NormalizeRelativeAngle(_lastMoveHeading - Direction));
    }

    public override void OnHitBot(HitBotEvent evt)
    {
        _moveHoldTurns = 1;
        _orbitSign *= -1;
        _lastOrbitFlipTurn = TurnNumber;
        double away = NormalizeAbsoluteAngle(BearingTo(evt.X, evt.Y) + 180.0);
        _lastMoveHeading = away;
        SetTurnLeft(NormalizeRelativeAngle(away - Direction));
        TargetSpeed = -8.0;
    }

    public override void OnHitByBullet(HitByBulletEvent evt)
    {
        int shooterId = evt.Bullet.OwnerId;
        if (_enemies.TryGetValue(shooterId, out var s))
        {
            double dmg = 4.0 * evt.Bullet.Power + (evt.Bullet.Power > 1.0 ? 2.0 * (evt.Bullet.Power - 1.0) : 0.0);
            s.DamageTaken += dmg;
            double avg = s.TurnsTracked > 0 ? s.TotalDistance / s.TurnsTracked : 500.0;
            s.DamageFactor = (s.DamageTaken + 10.0) * avg / Math.Max(s.TurnsTracked, 1);
            s.ThreatIndex += 0.25;
            s.PressureIndex += 0.2;
        }

        _panicUntil = Math.Max(_panicUntil, TurnNumber + 10);
        _moveHoldTurns = Math.Max(_moveHoldTurns, 1);
        _orbitSign *= -1;
    }

    public override void OnDeath(DeathEvent evt)
    {
        _enemies.Clear();
        _recentLocs.Clear();
        _visitedCells.Clear();
        _visitedCellOrder.Clear();
    }

    private EnemyInfo GetOrCreate(int id)
    {
        if (!_enemies.TryGetValue(id, out var e))
            _enemies[id] = e = new EnemyInfo { Id = id };
        return e;
    }

    private List<EnemyInfo> AliveEnemies() => _enemies.Values.Where(e => e.Alive).ToList();

    private void PurgeDeadEnemies()
    {
        foreach (var e in _enemies.Values.Where(e => e.Alive).ToList())
        {
            if (TurnNumber - e.LastSeenTurn > 42)
                e.Alive = false;
        }
    }

    private bool IsEnergyCritical() => Energy <= CriticalEnergy;
    private bool ShouldRam(EnemyInfo target) => Energy > 26.0 && target.Energy <= 18.0 && DistanceTo(target.X, target.Y) < 175.0;

    private EnemyInfo SelectPrimaryThreat(List<EnemyInfo> enemies)
    {
        EnemyInfo best = enemies[0];
        double bestScore = double.NegativeInfinity;

        foreach (var e in enemies)
        {
            double dist = DistanceTo(e.X, e.Y);
            double bodyBearing = Math.Abs(NormalizeRelativeAngle(DirectionTo(e.X, e.Y) - Direction));
            double closeFactor = 1.0 - Math.Min(dist, 780.0) / 780.0;
            double energyFactor = 0.5 + Math.Min(e.Energy, 100.0) / 100.0;
            double flankFactor = bodyBearing > 70.0 ? 1.05 : 0.0;
            double backFactor = bodyBearing > 135.0 ? 0.9 : 0.0;
            double agePenalty = Math.Max(0, TurnNumber - e.LastSeenTurn) * 0.05;
            double score = closeFactor * (2.0 + energyFactor + flankFactor + backFactor) + e.PressureIndex * 1.15 - agePenalty;

            if (dist < 170.0)
                score += 1.0;
            if (e.Id == _lastTargetId)
                score -= 0.08;

            if (score > bestScore)
            {
                bestScore = score;
                best = e;
            }
        }

        return best;
    }
}
